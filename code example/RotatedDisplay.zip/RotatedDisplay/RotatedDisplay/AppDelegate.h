//
//  AppDelegate.h
//  RotatedDisplay
//
//  Created by todd on 2/12/13.
//  Copyright (c) 2013 todd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
