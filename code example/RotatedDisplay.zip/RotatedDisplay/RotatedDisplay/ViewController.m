//
//  ViewController.m
//  RotatedDisplay
//
//  Created by todd on 2/12/13.
//  Copyright (c) 2013 todd. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
   // [self.theSwitch setOn:YES];
    
    switchState=[[NSUserDefaults standardUserDefaults]
                 
                 boolForKey:@"theStateOfTheSwitch"];
    
    [self.theSwitch setOn:switchState];
    
}
- (IBAction)theSlider:(id)sender {
}

- (IBAction)theButton:(id)sender {
}

- (IBAction)switchChanged:(id)sender {
    
    switchState = self.theSwitch.isOn;
    [[NSUserDefaults standardUserDefaults] setBool:switchState forKey:@"theStateOfTheSwitch"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotate {
    NSLog(@"in shouldAutorotate");
    
    return switchState;
    
}

@end
