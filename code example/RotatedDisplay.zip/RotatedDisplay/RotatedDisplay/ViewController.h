//
//  ViewController.h
//  RotatedDisplay
//
//  Created by todd on 2/12/13.
//  Copyright (c) 2013 todd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
    BOOL switchState;
}

@property (weak, nonatomic) IBOutlet UISwitch *theSwitch;

@end







