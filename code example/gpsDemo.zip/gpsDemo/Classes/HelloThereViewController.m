#import "HelloThereViewController.h"

@implementation HelloThereViewController

- (void)viewDidLoad { 	
	locationController = [[MyCLController alloc] init];
    NSLog(@"In here");
    
	locationController.delegate = self;
    
    
    // ** Don't forget to add NSLocationWhenInUseUsageDescription in MyApp-Info.plist and give it a string
    
  
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    if ([locationController.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationController.locationManager requestWhenInUseAuthorization];
    }

    
	[locationController.locationManager startUpdatingLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; 
}

- (void)dealloc {
	[locationController release];
    [super dealloc];
}

- (void)locationUpdate:(CLLocation *)location {
	locationLabel.text = [location description];
    NSLog([location description]);
    
}

- (void)locationError:(NSError *)error {
	locationLabel.text = [error description];
}

@end
