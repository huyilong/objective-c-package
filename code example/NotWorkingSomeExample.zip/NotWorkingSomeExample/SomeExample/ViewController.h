//
//  ViewController.h
//  SomeExample
//
//  Created by Todd Sproull on 1/28/15.
//  Copyright (c) 2015 Todd Sproull. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
    NSMutableArray *anotherArray2;
    
    NSDate *theDate;
}
@property (weak, nonatomic) IBOutlet UIButton *theButton;
@property (strong) NSMutableArray *myArray;


@end

