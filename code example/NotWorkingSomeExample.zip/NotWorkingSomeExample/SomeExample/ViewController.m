//
//  ViewController.m
//  SomeExample
//
//  Created by Todd Sproull on 1/28/15.
//  Copyright (c) 2015 Todd Sproull. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myArray = _myArray;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.myArray = [[NSMutableArray alloc] init];
    
    NSLog(@"The array is %@",self.myArray);
    NSLog(@"The array is %@",[self myArray]);
    
    
    theDate = [[NSDate alloc] init];
    NSDate *anotherDate = [NSDate date];
    
    anotherArray2 = [[NSMutableArray alloc] init];
    
    NSLog(@"The dates are %@ and %@",theDate,anotherDate);
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonPressed:(id)sender {
    
    NSLog(@"In here ");
    
    NSDate *myDate;
    //NSMutableArray *anotherArray = [[NSMutableArray alloc] init];
    
    for(int i=0;i<100000;i++) {
        
        myDate= [NSDate date];
        
      [anotherArray2 addObject:myDate];
          //[.myArray addObject:myDate];
    }
        
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
