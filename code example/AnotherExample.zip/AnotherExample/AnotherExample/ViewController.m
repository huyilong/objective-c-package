//
//  ViewController.m
//  AnotherExample
//
//  Created by Todd Sproull on 1/28/15.
//  Copyright (c) 2015 Todd Sproull. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end


@implementation ViewController

@synthesize theArray = _theArray;



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.theArray = [[NSMutableArray alloc] init];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)anotherButtonPressed:(id)sender forEvent:(UIEvent *)event {
    
    NSLog(@"In button press with event %@ from sender %@ ", event,sender);
    
}
- (IBAction)buttonPressed:(id)sender {
    
    NSMutableArray *someArray;
    
    NSDate *theDate = [NSDate date];
    
    NSDate *anotherDate = [[NSDate alloc] init];
    
    NSLog(@"Another date is %@",anotherDate);
  //  [anotherDate release];
  //  anotherDate=nil;
    
    
    
    [self.theArray addObject:theDate];
    
//
    NSLog(@"The size of the array is  %lu", (unsigned long)self.theArray.count);
    
    for(int i=0;i<1000000;i++){
        
        theDate = [NSDate date];
        
        [self.theArray addObject:theDate];
        //[someArray addObject:theDate];
        
    }
    
    //self.theArray = nil;
  //  [self.theArray removeAllObjects];
    
    //self.theArray = [[NSMutableArray alloc] init];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
