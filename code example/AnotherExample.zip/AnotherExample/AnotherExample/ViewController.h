//
//  ViewController.h
//  AnotherExample
//
//  Created by Todd Sproull on 1/28/15.
//  Copyright (c) 2015 Todd Sproull. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
 //   NSDate *theDate;
    
}

@property NSMutableArray *theArray;


@end

